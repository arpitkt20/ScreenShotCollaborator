package com.ScreenshotCollaborator.entry;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.io.File;
import java.io.IOException;
import java.util.concurrent.ExecutionException;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JSeparator;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.SwingWorker;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;

import org.jnativehook.GlobalScreen;
import org.jnativehook.NativeHookException;

import com.ScreenshotCollaborator.service.ExportToFile;
import com.ScreenshotCollaborator.service.KeyLogger;
import com.ScreenshotCollaborator.service.impl.ExportToPPT;
import com.ScreenshotCollaborator.service.impl.ExportToWord;
import com.ScreenshotCollaborator.util.ApplicationUtil;
import com.ScreenshotCollaborator.util.Constants;

/**
 * A java class uses swing components to generate the UI.
 * 
 * @author Arpit K Tiwari
 * @version 1.0
 * @since 2017-08-22
 */

public class Home {

	private JFrame frame;
	private String msg = null;
	public static JLabel lblMsg = null;
	private JButton btnExport = null;
	private JComboBox extensions = null;
	public static JTextField basePath;
	private JButton btnAppRunningStatus = null;
	public static JTextField subFolder;
	private JTextField fileName;
	public static JLabel lblCount = null;
	
	/**
	 * Launch the application.
	 * 
	 * @author Arpit K Tiwari
	 * @version 1.0
	 * @since 2017-08-22
	 * @throws NativeHookException
	 * @throws UnsupportedLookAndFeelException
	 * @throws IllegalAccessException
	 * @throws InstantiationException
	 * @throws ClassNotFoundException
	 * @throws IOException
	 */
	public static void main(String[] args) throws NativeHookException, ClassNotFoundException, InstantiationException,
			IllegalAccessException, UnsupportedLookAndFeelException {
		GlobalScreen.registerNativeHook();
		GlobalScreen.addNativeKeyListener(new KeyLogger());
		Logger logger = Logger.getLogger(GlobalScreen.class.getPackage().getName());
		logger.setLevel(Level.OFF);
		UIManager.setLookAndFeel("com.sun.java.swing.plaf.nimbus.NimbusLookAndFeel");
		Home app = new Home();
		app.frame.setVisible(true);
	}

	/**
	 * Create the application.
	 * 
	 * @author Arpit K Tiwari
	 * @version 1.0
	 * @throws IOException
	 * @since 2017-08-22
	 */
	public Home() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 * 
	 * @author Arpit K Tiwari
	 * @version 1.0
	 * @throws IOException
	 * @since 2017-08-22
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setIconImage(Toolkit.getDefaultToolkit().getImage(Home.class.getResource("/resource/logo.png")));
		frame.setTitle(Constants.APPLICATION_TITLE);
		frame.setBounds(100, 100, 450, 300);
		frame.setLocation(400, 200);
		frame.setSize(368, 282);
		frame.setResizable(false);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		JPanel panel = new JPanel();
		panel.setBackground(new Color(255, 255, 255));
		frame.getContentPane().add(panel, BorderLayout.CENTER);
		panel.setLayout(null);
		
		lblMsg = new JLabel("");
		lblMsg.setBounds(10, 222, 304, 30);
		panel.add(lblMsg);
		
		lblCount = new JLabel(String.valueOf(Constants.SCREENSHOT_COUNT));
		lblCount.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblCount.setBounds(323, 222, 37, 30);
		panel.add(lblCount);

		ApplicationUtil.getDataFromPropertyFile();
		Constants.BASE_FOLDER = Constants.SRC_FOLDER;
		if(Constants.SRC_FOLDER == null || Constants.SRC_FOLDER.trim().equalsIgnoreCase("")){
			Constants.SRC_FOLDER = Constants.DEFAULT_SRC_FOLDER;
			Constants.BASE_FOLDER = Constants.DEFAULT_SRC_FOLDER;
			ApplicationUtil.setDataInPropertyFile();
		}
		
		JLabel lblBaseFolder = new JLabel("Base Folder :");
		lblBaseFolder.setFont(new Font("Comic Sans MS", Font.BOLD | Font.ITALIC, 14));
		lblBaseFolder.setBounds(10, 12, 98, 25);
		panel.add(lblBaseFolder);

		basePath = new JTextField(Constants.BASE_FOLDER);
		basePath.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent arg0) {
				Pattern pattern = Pattern.compile("([A-Z|a-z]:\\\\[^*|\"<>?\n]*)");
				Matcher matcher = pattern.matcher(basePath.getText());  
				boolean matchStatus = matcher.matches();
				if(!matchStatus){
					JOptionPane.showMessageDialog(frame, "Invalid base directory", "Error", JOptionPane.ERROR_MESSAGE);
					basePath.requestFocus();;
				} else if(!(Constants.BASE_FOLDER.equalsIgnoreCase(basePath.getText()))) {
					Constants.SCREENSHOT_COUNT = 0;
					Home.lblCount.setText(String.valueOf(Constants.SCREENSHOT_COUNT));
					Constants.BASE_FOLDER = basePath.getText();
					ApplicationUtil.setSrcFolder();
					ApplicationUtil.setDataInPropertyFile();
				}
			}
		});

		basePath.setToolTipText("Base Directory : " + Constants.BASE_FOLDER);
		basePath.setFont(new Font("Comic Sans MS", Font.BOLD | Font.ITALIC, 12));
		basePath.setBounds(108, 10, 211, 30);
		panel.add(basePath);
		basePath.setColumns(10);
		basePath.setCursor(Cursor.getPredefinedCursor(Cursor.TEXT_CURSOR));

		JButton btnBrowseBaseFolder = new JButton("");
		btnBrowseBaseFolder.setToolTipText("Browse base folder directory");
		btnBrowseBaseFolder.setIcon(new ImageIcon(Home.class.getResource("/resource/browse.png")));
		btnBrowseBaseFolder.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				JFileChooser chooser = new JFileChooser();
				chooser.setCurrentDirectory(new java.io.File(Constants.BASE_FOLDER));
				chooser.setDialogTitle(Constants.FILE_CHOOSER_DIALOG_TITLE);
				chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
				chooser.setAcceptAllFileFilterUsed(false);
				String shortPath = "";
				if (chooser.showOpenDialog(null) == JFileChooser.APPROVE_OPTION) {
					msg = Constants.FOLDER_SELECTED;
					Constants.BASE_FOLDER = chooser.getSelectedFile().getAbsolutePath() + File.separator;
					ApplicationUtil.setDataInPropertyFile();
					basePath.setText(Constants.BASE_FOLDER);
					basePath.setToolTipText("Base Directory : " + Constants.BASE_FOLDER);
					ApplicationUtil.setSrcFolder();
					Constants.SCREENSHOT_COUNT = 0;
					Home.lblCount.setText(String.valueOf(Constants.SCREENSHOT_COUNT));
				} else {
					basePath.setText(Constants.BASE_FOLDER);
					basePath.setToolTipText("Base Directory : " + Constants.BASE_FOLDER);
				}
			}
		});
		btnBrowseBaseFolder.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnBrowseBaseFolder.setBounds(327, 12, 25, 25);
		panel.add(btnBrowseBaseFolder);
		
		JLabel lblSubFolder = new JLabel("Sub Folder  : ");
		lblSubFolder.setFont(new Font("Comic Sans MS", Font.BOLD | Font.ITALIC, 14));
		lblSubFolder.setBounds(10, 48, 98, 25);
		panel.add(lblSubFolder);
			
		subFolder = new JTextField("");
		subFolder.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent arg0) {
				if(!(subFolder.getText().equalsIgnoreCase(Constants.SUB_FOLDER))){
					Constants.SUB_FOLDER = subFolder.getText().trim();
					Constants.SCREENSHOT_COUNT = 0;
					Home.lblCount.setText(String.valueOf(Constants.SCREENSHOT_COUNT));
					ApplicationUtil.setSrcFolder();	
				}
			}
		});
		subFolder.setToolTipText("Full Screenshot Directory : "+Constants.SRC_FOLDER);
		subFolder.setFont(new Font("Comic Sans MS", Font.BOLD | Font.ITALIC, 12));
		subFolder.setColumns(10);
		subFolder.setBounds(108, 47, 211, 30);
		panel.add(subFolder);
		
		JLabel lblFileName = new JLabel("File Name  : ");
		lblFileName.setFont(new Font("Comic Sans MS", Font.BOLD | Font.ITALIC, 14));
		lblFileName.setBounds(10, 84, 111, 25);
		panel.add(lblFileName);

		fileName = new JTextField("");
		fileName.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				Pattern pattern = Pattern.compile("([^*|:\"<>?/\\\\]*)");
				Matcher matcher = pattern.matcher(fileName.getText());  
				boolean matchStatus = matcher.matches();
				if(!matchStatus){
					JOptionPane.showMessageDialog(frame, "Invalid File Name", "Error", JOptionPane.ERROR_MESSAGE);
					fileName.requestFocus();
				} else {
					Constants.FILE_NAME = fileName.getText();
				}
			}
		});
		fileName.setToolTipText("Name of the file for exporting screenshots");
		fileName.setFont(new Font("Comic Sans MS", Font.BOLD | Font.ITALIC, 12));
		fileName.setColumns(10);
		fileName.setBounds(108, 85, 211, 30);
		panel.add(fileName);

		JLabel lblExtension = new JLabel("Extension  : ");
		lblExtension.setFont(new Font("Comic Sans MS", Font.BOLD | Font.ITALIC, 14));
		lblExtension.setBounds(10, 120, 98, 25);
		panel.add(lblExtension);

		extensions = new JComboBox(Constants.EXTENSIONS);
		extensions.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		extensions.setFont(new Font("Comic Sans MS", Font.BOLD | Font.ITALIC, 12));
		extensions.setForeground(new Color(0, 0, 0));
		extensions.setToolTipText(Constants.EXTENSION_TOOLTIP);
		extensions.setBackground(new Color(70, 130, 180));
		extensions.setBounds(108, 118, 211, 26);
		panel.add(extensions);

		btnAppRunningStatus = new JButton("");
		btnAppRunningStatus.setToolTipText("Screenshot Capturing Status - Record/Pause");
		btnAppRunningStatus.setIcon(new ImageIcon(Home.class.getResource("/resource/pause.png")));
		btnAppRunningStatus.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnAppRunningStatus.setBounds(10, 159, 75, 50);
		panel.add(btnAppRunningStatus);
		btnAppRunningStatus.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(Constants.APPLICATION_RUNNING_STATUS){
					btnAppRunningStatus.setIcon(new ImageIcon(Home.class.getResource("/resource/record.png")));
					Constants.APPLICATION_RUNNING_STATUS = false;
				} else{
					btnAppRunningStatus.setIcon(new ImageIcon(Home.class.getResource("/resource/pause.png")));
					Constants.APPLICATION_RUNNING_STATUS = true;
				}
			}
		});

		btnExport = new JButton("");
		btnExport.setToolTipText(Constants.EXPORT_BUTTON_TOOLTIP);
		btnExport.setBackground(Color.BLACK);
		btnExport.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnExport.setIcon(new ImageIcon(Home.class.getResource("/resource/export.png")));
		btnExport.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				SwingWorker<Boolean, Void> worker = new SwingWorker<Boolean, Void>() {
					@Override
					protected Boolean doInBackground() throws Exception {
						if(!("".equalsIgnoreCase(fileName.getText().trim()))){
							lblMsg.setText("");
							lblMsg.setIcon(new ImageIcon(Home.class.getResource("/resource/Saving.gif")));
							btnExport.setEnabled(false);
							ExportToFile exportToFile = null;
							if (extensions.getSelectedItem().toString().toUpperCase().contains(Constants.FILE_FORMAT_DOCX)) {
								exportToFile = new ExportToWord();
								msg = exportToFile.export();
							} else if (extensions.getSelectedItem().toString().toUpperCase().contains(Constants.FILE_FORMAT_PPTX)) {
								exportToFile = new ExportToPPT();
								msg = exportToFile.export();
							}
							return true;	
						} else{
							lblMsg.setText(Constants.FILE_NAME_MISSING);
							fileName.requestFocus();
							return false;
						}
					}

					@Override
					protected void done() {
						boolean status;
						try {
							status = get();
							if (status == true) {
								lblMsg.setIcon(null);
								lblMsg.setText(msg);
								btnExport.setEnabled(true);
							}
						} catch (InterruptedException e) {
							lblMsg.setText(e.getMessage());
						} catch (ExecutionException e) {
							lblMsg.setText(e.getMessage());
						}
					}
				};
				worker.execute();
			}
		});
		btnExport.setBounds(108, 159, 244, 50);
		panel.add(btnExport);
		
		JSeparator hSeparator = new JSeparator();
		hSeparator.setBounds(0, 220, 370, 2);
		panel.add(hSeparator);
		
		JSeparator vSeparator = new JSeparator();
		vSeparator.setOrientation(SwingConstants.VERTICAL);
		vSeparator.setBounds(318, 221, 7, 31);
		panel.add(vSeparator);
	}
}