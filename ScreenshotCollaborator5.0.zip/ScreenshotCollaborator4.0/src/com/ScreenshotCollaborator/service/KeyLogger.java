package com.ScreenshotCollaborator.service;

import org.jnativehook.keyboard.NativeKeyEvent;
import org.jnativehook.keyboard.NativeKeyListener;

import com.ScreenshotCollaborator.entry.Home;
import com.ScreenshotCollaborator.util.Constants;

/**
 * A java class built on top of jnativehook api to get details of
 * everyKeystroke.
 * 
 * @author Arpit K Tiwari
 * @version 1.0
 * @since 2017-08-22
 */

public class KeyLogger implements NativeKeyListener {

	/**
	 * Method to get invoked on keyPressedEvent
	 * 
	 * @author Arpit K Tiwari
	 * @version 1.0
	 * @since 2017-08-22
	 * @param NativeKeyEvent
	 * @return null.
	 */

	@Override
	public void nativeKeyPressed(NativeKeyEvent key) {
		if (Constants.APPLICATION_RUNNING_STATUS) {
			if (key.getKeyCode() == NativeKeyEvent.VC_PRINTSCREEN) {
				CaptureShot shot = new CaptureShot();
				String status = shot.takeScreenShot();
				Home.lblMsg.setText(status);
				Constants.SCREENSHOT_COUNT = Constants.SCREENSHOT_COUNT + 1;
				Home.lblCount.setText(String.valueOf(Constants.SCREENSHOT_COUNT));
			}
		}
	}

	/**
	 * Method to get invoked on keyReleasedEvent
	 * 
	 * @author Arpit K Tiwari
	 * @version 1.0
	 * @since 2017-08-22
	 * @param NativeKeyEvent
	 * @return null.
	 */

	@Override
	public void nativeKeyReleased(NativeKeyEvent key) {

	}

	/**
	 * Method to get invoked on keyTypedEvent
	 * 
	 * @author Arpit K Tiwari
	 * @version 1.0
	 * @since 2017-08-22
	 * @param NativeKeyEvent
	 * @return null.
	 */

	@Override
	public void nativeKeyTyped(NativeKeyEvent key) {
	}
}
