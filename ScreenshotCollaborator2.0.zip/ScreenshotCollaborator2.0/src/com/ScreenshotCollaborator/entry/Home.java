package com.ScreenshotCollaborator.entry;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.io.File;
import java.io.IOException;
import java.util.concurrent.ExecutionException;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JSeparator;
import javax.swing.JTextField;
import javax.swing.SwingWorker;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;

import org.jnativehook.GlobalScreen;
import org.jnativehook.NativeHookException;

import com.ScreenshotCollaborator.service.ExportToFile;
import com.ScreenshotCollaborator.service.KeyLogger;
import com.ScreenshotCollaborator.service.impl.ExportToPPT;
import com.ScreenshotCollaborator.service.impl.ExportToWord;
import com.ScreenshotCollaborator.util.ApplicationUtil;
import com.ScreenshotCollaborator.util.Constants;

/**
 * A java class uses swing components to generate the UI.
 * 
 * @author Arpit K Tiwari
 * @version 1.0
 * @since 2017-08-22
 */

public class Home {

	private JFrame frame;
	private String msg = null;
	public static JLabel lblMsg = null;
	private JButton btnExport = null;
	private JComboBox extensions = null;
	public static JLabel lblBatchNum = null;
	public static JLabel lblCountNum = null;
	public static JTextField basePath;
	private JButton btnAppRunningStatus = null;

	/**
	 * Launch the application.
	 * 
	 * @author Arpit K Tiwari
	 * @version 1.0
	 * @since 2017-08-22
	 * @throws NativeHookException
	 * @throws UnsupportedLookAndFeelException
	 * @throws IllegalAccessException
	 * @throws InstantiationException
	 * @throws ClassNotFoundException
	 * @throws IOException
	 */
	public static void main(String[] args) throws NativeHookException, ClassNotFoundException, InstantiationException,
			IllegalAccessException, UnsupportedLookAndFeelException {
		GlobalScreen.registerNativeHook();
		GlobalScreen.addNativeKeyListener(new KeyLogger());
		Logger logger = Logger.getLogger(GlobalScreen.class.getPackage().getName());
		logger.setLevel(Level.OFF);
		UIManager.setLookAndFeel("com.sun.java.swing.plaf.nimbus.NimbusLookAndFeel");
		Home app = new Home();
		app.frame.setVisible(true);
	}

	/**
	 * Create the application.
	 * 
	 * @author Arpit K Tiwari
	 * @version 1.0
	 * @throws IOException
	 * @since 2017-08-22
	 */
	public Home() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 * 
	 * @author Arpit K Tiwari
	 * @version 1.0
	 * @throws IOException
	 * @since 2017-08-22
	 */
	private void initialize() {
		ApplicationUtil.getDataFromPropertyFile();
		if(Constants.SRC_FOLDER == null || Constants.SRC_FOLDER.trim().equalsIgnoreCase("")){
			Constants.SRC_FOLDER = Constants.DEFAULT_SRC_FOLDER;
			ApplicationUtil.setDataInPropertyFile();
		}

		frame = new JFrame();
		frame.setIconImage(Toolkit.getDefaultToolkit().getImage(Home.class.getResource("/resource/logo.png")));
		frame.setTitle(Constants.APPLICATION_TITLE);
		frame.setBounds(100, 100, 450, 300);
		frame.setLocation(400, 200);
		frame.setSize(366, 243);
		frame.setResizable(false);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		JPanel panel = new JPanel();
		panel.setBackground(new Color(255, 255, 255));
		frame.getContentPane().add(panel, BorderLayout.CENTER);
		panel.setLayout(null);

		JLabel lblBaseFolder = new JLabel("Base Folder :");
		lblBaseFolder.setFont(new Font("Comic Sans MS", Font.BOLD | Font.ITALIC, 14));
		lblBaseFolder.setBounds(10, 12, 98, 25);
		panel.add(lblBaseFolder);

		basePath = new JTextField("");
		basePath.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent arg0) {
				Pattern pattern = Pattern.compile("([A-Z|a-z]:\\\\[^*|\"<>?\n]*)");
				Matcher matcher = pattern.matcher(basePath.getText());  
				boolean matchStatus = matcher.matches();
				if(!matchStatus){
					JOptionPane.showMessageDialog(frame, "Invalid base directory", "Error", JOptionPane.ERROR_MESSAGE);
					basePath.setFocusable(true);
				} else if(!(Constants.SRC_FOLDER.equalsIgnoreCase(basePath.getText()))) {
					Constants.BATCH_COUNT =  1;
					Constants.SCREENSHOT_COUNT = 0;
					Constants.BATCH_FOLDER = null;
					Home.lblBatchNum.setText(Constants.BATCH_NUM_LABEL + Constants.BATCH_COUNT);
					Home.lblCountNum.setText(Constants.COUNT_NUM_LABEL + Constants.SCREENSHOT_COUNT);
				} else {
					Constants.SRC_FOLDER = basePath.getText();
					if (ApplicationUtil.getPathLength(Constants.SRC_FOLDER) > 15) {
						basePath.setText(ApplicationUtil.getShortPath(Constants.SRC_FOLDER));
					} else {
						basePath.setText(Constants.SRC_FOLDER);
					}
				}
			}
		});
				
		if (ApplicationUtil.getPathLength(Constants.SRC_FOLDER) > 15) {
			basePath.setText(ApplicationUtil.getShortPath(Constants.SRC_FOLDER));
		} else {
			basePath.setText(Constants.SRC_FOLDER);
		}
		basePath.setToolTipText("Base Directory : " + Constants.SRC_FOLDER);
		basePath.setFont(new Font("Comic Sans MS", Font.BOLD | Font.ITALIC, 12));
		basePath.setBounds(108, 13, 211, 25);
		panel.add(basePath);
		basePath.setColumns(10);
		basePath.setCursor(Cursor.getPredefinedCursor(Cursor.TEXT_CURSOR));

		JButton btnBrowseButton = new JButton("");
		btnBrowseButton.setToolTipText("Browse base folder directory");
		btnBrowseButton.setIcon(new ImageIcon(Home.class.getResource("/resource/browse.png")));
		btnBrowseButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				JFileChooser chooser = new JFileChooser();
				chooser.setCurrentDirectory(new java.io.File(Constants.SRC_FOLDER));
				chooser.setDialogTitle(Constants.FILE_CHOOSER_DIALOG_TITLE);
				chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
				chooser.setAcceptAllFileFilterUsed(false);
				String shortPath = "";
				if (chooser.showOpenDialog(null) == JFileChooser.APPROVE_OPTION) {
					msg = Constants.FOLDER_SELECTED;
					Constants.SRC_FOLDER = chooser.getSelectedFile().getAbsolutePath() + File.separator;
					ApplicationUtil.setDataInPropertyFile();
					if (ApplicationUtil.getPathLength(Constants.SRC_FOLDER) > 15) {
						shortPath = ApplicationUtil.getShortPath(Constants.SRC_FOLDER);
						basePath.setText(shortPath);
					} else {
						basePath.setText(Constants.SRC_FOLDER);
					}

					basePath.setToolTipText("Base Directory : " + Constants.SRC_FOLDER);
				} else {
					if (ApplicationUtil.getPathLength(Constants.SRC_FOLDER) > 15) {
						shortPath = ApplicationUtil.getShortPath(Constants.SRC_FOLDER);
						basePath.setText(shortPath);
					} else {
						basePath.setText(Constants.SRC_FOLDER);
					}
					basePath.setToolTipText("Base Directory : " + Constants.SRC_FOLDER);
				}
			}
		});
		btnBrowseButton.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnBrowseButton.setBounds(327, 12, 25, 25);
		panel.add(btnBrowseButton);

		lblMsg = new JLabel("");
		lblMsg.setToolTipText("Status");
		lblMsg.setBounds(10, 189, 342, 21);
		panel.add(lblMsg);

		lblMsg.setText("");

		btnExport = new JButton("");
		btnExport.setToolTipText(Constants.EXPORT_BUTTON_TOOLTIP);
		btnExport.setBackground(Color.BLACK);
		btnExport.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnExport.setIcon(new ImageIcon(Home.class.getResource("/resource/export.png")));
		btnExport.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				SwingWorker<Boolean, Void> worker = new SwingWorker<Boolean, Void>() {
					@Override
					protected Boolean doInBackground() throws Exception {
						lblMsg.setText("");
						lblMsg.setIcon(new ImageIcon(Home.class.getResource("/resource/Saving.gif")));
						btnExport.setEnabled(false);
						ExportToFile exportToFile = null;
						if (extensions.getSelectedItem().toString().toUpperCase().contains(Constants.FILE_FORMAT_DOCX)) {
							exportToFile = new ExportToWord();
							msg = exportToFile.export();
						} else if (extensions.getSelectedItem().toString().toUpperCase().contains(Constants.FILE_FORMAT_PPTX)) {
							exportToFile = new ExportToPPT();
							msg = exportToFile.export();
						}
						return true;
					}

					@Override
					protected void done() {
						boolean status;
						try {
							status = get();
							if (status == true) {
								lblMsg.setIcon(null);
								lblMsg.setText(msg);
								btnExport.setEnabled(true);
							}
						} catch (InterruptedException e) {
							lblMsg.setText(e.getMessage());
						} catch (ExecutionException e) {
							lblMsg.setText(e.getMessage());
						}
					}
				};
				worker.execute();
			}
		});
		btnExport.setBounds(108, 89, 244, 61);
		panel.add(btnExport);

		JSeparator separator_1 = new JSeparator();
		separator_1.setBounds(0, 186, 360, 3);
		panel.add(separator_1);

		extensions = new JComboBox(Constants.EXTENSIONS);
		extensions.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		extensions.setFont(new Font("Comic Sans MS", Font.BOLD | Font.ITALIC, 12));
		extensions.setForeground(new Color(0, 0, 0));
		extensions.setToolTipText(Constants.EXTENSION_TOOLTIP);
		extensions.setBackground(new Color(70, 130, 180));
		extensions.setBounds(108, 48, 211, 25);
		panel.add(extensions);

		JSeparator separator = new JSeparator();
		separator.setBounds(0, 161, 360, 3);
		panel.add(separator);

		lblBatchNum = new JLabel(Constants.BATCH_NUM_LABEL + Constants.BATCH_COUNT);
		lblBatchNum.setToolTipText(Constants.BATCH_NUM_LABEL_TOOLTIP);
		lblBatchNum.setBounds(10, 163, 72, 21);
		panel.add(lblBatchNum);

		lblCountNum = new JLabel(Constants.COUNT_NUM_LABEL + Constants.SCREENSHOT_COUNT);
		lblCountNum.setToolTipText(Constants.COUNT_NUM_LABEL_TOOLTIP);
		lblCountNum.setBounds(260, 163, 90, 21);
		panel.add(lblCountNum);

		JButton btnInfoButton = new JButton("");
		btnInfoButton.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnInfoButton.setToolTipText(Constants.HELP_TOOLTIP);
		btnInfoButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String help = Constants.HELP;
				JOptionPane.showMessageDialog(frame, help, "About", JOptionPane.INFORMATION_MESSAGE);
			}
		});
		btnInfoButton.setIcon(new ImageIcon(Home.class.getResource("/resource/info.png")));
		btnInfoButton.setBounds(327, 48, 25, 25);
		panel.add(btnInfoButton);

		JLabel lblNewLabel = new JLabel(Constants.EXTENSION_LABEL);
		lblNewLabel.setFont(new Font("Comic Sans MS", Font.BOLD | Font.ITALIC, 14));
		lblNewLabel.setBounds(10, 47, 98, 31);
		panel.add(lblNewLabel);
		
		btnAppRunningStatus = new JButton("");
		btnAppRunningStatus.setToolTipText("Screenshot Capturing Status - Record/Pause");
		btnAppRunningStatus.setIcon(new ImageIcon(Home.class.getResource("/resource/record.png")));
		btnAppRunningStatus.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnAppRunningStatus.setBounds(9, 89, 89, 61);
		panel.add(btnAppRunningStatus);
		btnAppRunningStatus.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(Constants.APPLICATION_RUNNING_STATUS){
					btnAppRunningStatus.setIcon(new ImageIcon(Home.class.getResource("/resource/pause.png")));
					Constants.APPLICATION_RUNNING_STATUS = false;
				} else{
					btnAppRunningStatus.setIcon(new ImageIcon(Home.class.getResource("/resource/record.png")));
					Constants.APPLICATION_RUNNING_STATUS = true;
				}
			}
		});
	}
}