package com.ScreenshotCollaborator.service;

import java.awt.AWTException;
import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.imageio.ImageIO;

import com.ScreenshotCollaborator.util.Constants;

/**
 * A java class to take screenshot and save it as a jpg file.
 * 
 * @author Arpit K Tiwari
 * @version 1.0
 * @since 2017-08-22
 */

public class CaptureShot {

	/**
	 * Method to take screenshots and save as jpg
	 * 
	 * @author Arpit K Tiwari
	 * @version 1.0
	 * @since 2017-08-22
	 * @param null
	 * @return status.
	 */

	public String takeScreenShot() {
		String status = "";
		Robot robot = null;
		String fileName = null;
		Rectangle screenRect = null;
		BufferedImage screenFullImage = null;
		File srcFolder = null;
		try {
			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddhhmmss");
			Date today = new Date();
			if(Constants.BATCH_FOLDER == null){
				Constants.BATCH_FOLDER = Constants.SRC_FOLDER + Constants.BATCH + Constants.UNDERSCORE + sdf.format(today) + File.separator;
			}
			srcFolder = new File(Constants.BATCH_FOLDER);
			if (!(srcFolder.exists())) {
				srcFolder.mkdirs();
			}
			fileName = srcFolder.getAbsolutePath() + File.separator + Constants.BATCH + Constants.UNDERSCORE
					+ Constants.BATCH_COUNT + Constants.UNDERSCORE + sdf.format(today) + Constants.DOT
					+ Constants.IMG_FORMAT;
			robot = new Robot();
			screenRect = new Rectangle(Toolkit.getDefaultToolkit().getScreenSize());
			screenFullImage = robot.createScreenCapture(screenRect);
			ImageIO.write(screenFullImage, Constants.IMG_FORMAT, new File(fileName));
			status = Constants.SHOT_CAPTURED_SUCCESS;
		} catch (IOException e) {
			status = Constants.SHOT_CAPTURED_FAILED;
		} catch (AWTException e) {
			status = Constants.SHOT_CAPTURED_FAILED;
		}
		return status;
	}
}